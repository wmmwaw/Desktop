﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Todo.Entities;

namespace Todo.Repository
{
    public static class UserRepository
    {
        // Список зарегистрированных пользователей
        private static readonly List<UserModel> Users = new List<UserModel>()
    {
        new UserModel()
        {
            Name = "www",
            Email = "w@w.com",
            Password = "123456"
        }
    };

        public static UserModel CurrentUser { get; set; }

        public static async Task<string> RegisterAsync(UserModel user)
        {
            // Проверяем, есть ли пользователь в локальном списке
            if (Users.Any(u => u.Email == user.Email))
            {
                return "Пользователь с таким email уже существует (локально).";
            }

            // Отправляем запрос к API для регистрации
            bool isRegistered = await ApiClient.RegisterAsync(user.Email, user.Password);

            if (isRegistered)
            {
                Users.Add(user); // Добавляем в локальный список
                return "Пользователь успешно зарегистрирован.";
            }
            else
            {
                return "Ошибка при регистрации через API.";
            }
        }

        public static async Task<UserModel> LoginAsync(string email, string password)
        {
            bool success = await ApiClient.LoginAsync(email, password);
            return success
                ? new UserModel { Email = email }
                : null;
        }
    }
}