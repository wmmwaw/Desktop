﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media.Animation;
using Todo.Entities;
using Todo.Repository;

namespace Todo.View
{
    public partial class Main : Page, INotifyPropertyChanged
    {
        private string _username;
        private ObservableCollection<TaskModel> _allTasks;
        private ObservableCollection<TaskModel> _filteredTasks;
        private ObservableCollection<TaskModel> _allCompletedTasks;

        public string UserName
        {
            get => _username;
            set
            {
                _username = value;
                OnPropertyChanged();
            }
        }

        public ObservableCollection<TaskModel> Tasks
        {
            get => _filteredTasks;
            set
            {
                _filteredTasks = value;
                OnPropertyChanged();
            }
        }

        public Main()
        {
            InitializeComponent();
            Loaded += Main_Loaded;
            TaskManager.Instance.TasksUpdated += RefreshTasks;
            DataContext = this;
        }

        private async void Main_Loaded(object sender, RoutedEventArgs e)
        {
            await LoadTasksFromApi();

            if (UserRepository.CurrentUser != null)
            {
                UserName = UserRepository.CurrentUser.Name;
            }
        }

        private async Task LoadTasksFromApi()
        {
            try
            {
                var apiTasks = await ApiClient.GetTasksAsync();

                _allTasks = new ObservableCollection<TaskModel>(apiTasks.Where(t => !t.IsCompleted));
                _allCompletedTasks = new ObservableCollection<TaskModel>(apiTasks.Where(t => t.IsCompleted));

                Tasks = new ObservableCollection<TaskModel>(_allTasks);
                taskListBox.ItemsSource = Tasks;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки задач: {ex.Message}");

                // Fallback to local data
                _allTasks = TaskManager.Instance.AllTasks;
                _allCompletedTasks = TaskManager.Instance.CompletedTasks;
                Tasks = new ObservableCollection<TaskModel>(_allTasks);
                taskListBox.ItemsSource = Tasks;
            }
        }

        private async void RefreshTasks()
        {
            try
            {
                var apiTasks = await ApiClient.GetTasksAsync();

                _allTasks.Clear();
                _allCompletedTasks.Clear();

                foreach (var task in apiTasks)
                {
                    if (task.IsCompleted)
                        _allCompletedTasks.Add(task);
                    else
                        _allTasks.Add(task);
                }

                Tasks.Clear();
                foreach (var task in _allTasks)
                {
                    Tasks.Add(task);
                }

                taskListBox.Items.Refresh();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка обновления задач: {ex.Message}");
            }
        }

        private async void FilterTasksByCategory(string category)
        {
            try
            {
                var apiTasks = await ApiClient.GetTasksAsync();
                var filtered = apiTasks.Where(t => t.Category == category && !t.IsCompleted).ToList();

                Tasks.Clear();
                foreach (var task in filtered)
                {
                    Tasks.Add(task);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка фильтрации задач: {ex.Message}");

                Tasks.Clear();
                foreach (var task in _allTasks.Where(t => t.Category == category))
                {
                    Tasks.Add(task);
                }
            }
        }

        private void CategoryLabel_Click(object sender, MouseButtonEventArgs e)
        {
            if (sender is Label label && label.Tag is string category)
            {
                FilterTasksByCategory(category);
            }
        }

        private void taskListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (taskListBox.SelectedItem is TaskModel selectedTask)
            {
                taskTitleTextBlock.Text = selectedTask.Title;
                taskDueDateTextBlock.Text = selectedTask.DueDate.ToString("HH:mm");
                taskDateTextBlock.Text = selectedTask.DueDate.ToString("dd/MM/yyyy");
                taskDescriptionTextBlock.Text = selectedTask.Description;

                taskDetailsBorder.Visibility = Visibility.Visible;
                okButton.Visibility = Visibility.Visible;
                deleteButton.Visibility = Visibility.Visible;

                UpdateUIForTask(selectedTask);
            }
            else
            {
                taskDetailsBorder.Visibility = Visibility.Collapsed;
                okButton.Visibility = Visibility.Collapsed;
                deleteButton.Visibility = Visibility.Collapsed;
            }
        }

        private void UpdateUIForTask(TaskModel task)
        {
            if (task.IsCompleted)
            {
                okButton.Visibility = Visibility.Collapsed;
                deleteButton.Visibility = Visibility.Collapsed;
            }
            else
            {
                taskDetailsBorder.Visibility = Visibility.Visible;
                okButton.Visibility = Visibility.Visible;
                deleteButton.Visibility = Visibility.Visible;
            }
        }

        private async void CheckBoxTask_Checked(object sender, RoutedEventArgs e)
        {
            if (sender is CheckBox checkBox && checkBox.DataContext is TaskModel selectedTask)
            {
                try
                {
                    selectedTask.IsCompleted = true;
                    if (await ApiClient.UpdateTaskAsync(selectedTask))
                    {
                        Tasks.Remove(selectedTask);
                        TaskManager.Instance.CompleteTask(selectedTask);
                        taskListBox.Items.Refresh();
                        UpdateUIForTask(selectedTask);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка завершения задачи: {ex.Message}");
                }
            }
        }

        private async void CheckBoxTask_Unchecked(object sender, RoutedEventArgs e)
        {
            if (sender is CheckBox checkBox && checkBox.DataContext is TaskModel selectedTask)
            {
                try
                {
                    selectedTask.IsCompleted = false;
                    if (await ApiClient.UpdateTaskAsync(selectedTask))
                    {
                        TaskManager.Instance.UncompleteTask(selectedTask);
                        UpdateUIForTask(selectedTask);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка возобновления задачи: {ex.Message}");
                }
            }
        }

        private async void okButton_Click(object sender, RoutedEventArgs e)
        {
            if (taskListBox.SelectedItem is TaskModel selectedTask)
            {
                try
                {
                    selectedTask.IsCompleted = true;
                    if (await ApiClient.UpdateTaskAsync(selectedTask))
                    {
                        Tasks.Remove(selectedTask);
                        TaskManager.Instance.CompleteTask(selectedTask);
                        taskListBox.Items.Refresh();
                        UpdateUIForTask(selectedTask);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка завершения задачи: {ex.Message}");
                }
            }
        }

        private async void deleteButton_Click(object sender, RoutedEventArgs e)
        {
            if (taskListBox.SelectedItem is TaskModel selectedTask)
            {
                try
                {
                    if (await ApiClient.DeleteTaskAsync(selectedTask.Id))
                    {
                        _allTasks.Remove(selectedTask);
                        Tasks.Remove(selectedTask);
                        ClearTaskDetails();
                        taskListBox.Items.Refresh();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка удаления задачи: {ex.Message}");
                }
            }
        }

        private void ClearTaskDetails()
        {
            taskTitleTextBlock.Text = string.Empty;
            taskDueDateTextBlock.Text = string.Empty;
            taskDescriptionTextBlock.Text = string.Empty;
            okButton.Visibility = Visibility.Collapsed;
            deleteButton.Visibility = Visibility.Collapsed;
        }

        private void OpenHistoryWindow(object sender, MouseButtonEventArgs e)
        {
            _filteredTasks.Clear();
            foreach (var task in _allCompletedTasks)
            {
                _filteredTasks.Add(task);
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            TaskCreation taskCreation = new TaskCreation();
            taskCreation.TaskCreated += TaskCreation_TaskCreated;
            DoubleAnimation fadeOut = new DoubleAnimation(1, 0, TimeSpan.FromSeconds(0.3));
            fadeOut.Completed += (s, e1) =>
            {
                NavigationService.Navigate(taskCreation);
                DoubleAnimation fadeIn = new DoubleAnimation(0, 1, TimeSpan.FromSeconds(0.3));
                taskCreation.BeginAnimation(UIElement.OpacityProperty, fadeIn);
            };
            this.BeginAnimation(UIElement.OpacityProperty, fadeOut);
        }

        private async void TaskCreation_TaskCreated(object sender, TaskModel newTask)
        {
            try
            {
                var createdTask = await ApiClient.CreateTaskAsync(newTask);
                if (createdTask != null)
                {
                    TaskManager.Instance.SaveTask(createdTask);
                    Tasks.Add(createdTask);
                    taskListBox.Items.Refresh();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка создания задачи: {ex.Message}");
            }
        }

        private void ShowAllTasks(object sender, MouseButtonEventArgs e)
        {
            Tasks.Clear();
            foreach (var task in _allTasks)
            {
                Tasks.Add(task);
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}