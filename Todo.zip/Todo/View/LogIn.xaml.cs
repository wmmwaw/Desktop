﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;
using Todo.Entities;
using Todo.Repository;

namespace Todo.View
{
    public partial class LogIn : Page
    {
        public LogIn()
        {
            InitializeComponent();

            EmailTextBox.Text = "Введите почту";
            EmailTextBox.Foreground = new SolidColorBrush(Colors.Gray);
            PasswordTextBox.Text = "Введите пароль";
            PasswordTextBox.Foreground = new SolidColorBrush(Colors.Gray);
        }

        private void EmailTextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            if (EmailTextBox.Text == "Введите почту")
            {
                EmailTextBox.Text = "";
                EmailTextBox.Foreground = new SolidColorBrush(Colors.Black);
            }
        }

        private void EmailTextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(EmailTextBox.Text))
            {
                EmailTextBox.Text = "Введите почту";
                EmailTextBox.Foreground = new SolidColorBrush(Colors.Gray);
            }
        }

        private void PasswordTextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            if (PasswordTextBox.Text == "Введите пароль")
            {
                PasswordTextBox.Text = "";
                PasswordTextBox.Foreground = new SolidColorBrush(Colors.Black);
            }
        }

        private void PasswordTextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(PasswordTextBox.Text))
            {
                PasswordTextBox.Text = "Введите пароль";
                PasswordTextBox.Foreground = new SolidColorBrush(Colors.Gray);
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            AnimatePageTransition(new Registration());
        }

        private async void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            string email = EmailTextBox.Text;
            string password = PasswordTextBox.Text;

            // Проверка на "серые" подсказки
            if (email == "Введите почту" || password == "Введите пароль")
            {
                MessageBox.Show("Пожалуйста, введите email и пароль", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            try
            {
                // Показываем индикатор загрузки
                var button = (Button)sender;
                button.IsEnabled = false;
                button.Content = "Вход...";

                // Используем API для аутентификации
                bool loginSuccess = await ApiClient.LoginAsync(email, password);

                if (loginSuccess)
                {
                    // Получаем данные пользователя (если нужно)
                    UserModel user = new UserModel { Email = email };
                    UserRepository.CurrentUser = user;

                    AnimatePageTransition(new MainEmpty());
                }
                else
                {
                    MessageBox.Show("Неверный email или пароль.", "Ошибка",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при входе: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                // Восстанавливаем кнопку
                if (sender is Button button)
                {
                    button.IsEnabled = true;
                    button.Content = "Войти";
                }
            }
        }

        private void AnimatePageTransition(Page newPage)
        {
            DoubleAnimation fadeOut = new DoubleAnimation(1, 0, TimeSpan.FromSeconds(0.3));
            fadeOut.Completed += (s, e) =>
            {
                NavigationService.Navigate(newPage);
                DoubleAnimation fadeIn = new DoubleAnimation(0, 1, TimeSpan.FromSeconds(0.3));
                newPage.BeginAnimation(OpacityProperty, fadeIn);
            };
            this.BeginAnimation(OpacityProperty, fadeOut);
        }
    }
}