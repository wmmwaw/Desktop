
namespace Todo.Entities
{
    public class Class1
    {
    }

}
