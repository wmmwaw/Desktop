
namespace Desktop
{
    public class Class1
    {
    }

}
