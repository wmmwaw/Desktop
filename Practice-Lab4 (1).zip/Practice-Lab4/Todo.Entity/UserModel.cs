﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace Todo.Entitites
{

    public class UserModel
    {

    }
}
