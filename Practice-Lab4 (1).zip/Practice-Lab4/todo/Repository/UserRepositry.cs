﻿using System;
using System.Collections.Generic;
using todo.Repository;

namespace todo.Repository
{
    internal class User
    {
        public string Name { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }

        public User(string name, string email, string password)
        {
            Name = name;
            Email = email;
            Password = password;
        }
    }
}

namespace todo.Repository
{
    internal class UserRepository
    {
        private List<User> users = new List<User>();

        public void RegisterUser(string name, string email, string password)
        {
            // Проверка на уникальность email
            if (users.Exists(u => u.Email == email))
            {
                Console.WriteLine("Пользователь с таким email уже существует.");
            }
            else
            {
                // Создаем нового пользователя и добавляем в список
                User newUser = new User(name, email, password);
                users.Add(newUser);
                Console.WriteLine("Пользователь успешно зарегистрирован.");
            }
        }

        public User AuthenticateUser(string email, string password)
        {
            // Проверяем существует ли пользователь с указанным email и паролем
            User user = users.Find(u => u.Email == email && u.Password == password);
            return user;
        }
    }
}


