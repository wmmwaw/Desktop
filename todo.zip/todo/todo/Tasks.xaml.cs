﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Windows;
using Newtonsoft.Json;

namespace todo
{
    public partial class TasksWindow : Window
    {
        public ObservableCollection<TaskItem> Tasks { get; private set; }
        private bool showCompletedTasks = false; // Флаг для отслеживания отображаемых задач
        private const string tasksFilePath = "tasks.json"; // Путь к файлу для хранения задач

        public TasksWindow()
        {
            InitializeComponent();

            Tasks = new ObservableCollection<TaskItem>();
            TaskList.ItemsSource = Tasks; // Изначально отображаем все задачи
            LoadTasks(); // Загружаем задачи при запуске
        }

        private void AddTask_Click(object sender, RoutedEventArgs e)
        {
            var addTaskWindow = new AddTaskWindow();
            addTaskWindow.ShowDialog();

            if (addTaskWindow.IsTaskCreated && !string.IsNullOrWhiteSpace(addTaskWindow.TaskTitle))
            {
                var newTask = new TaskItem
                {
                    Title = addTaskWindow.TaskTitle,
                    IsComplete = false,
                    Description = addTaskWindow.TaskDescription
                };
                Tasks.Add(newTask);
                UpdateTaskList(); // Обновляем список после добавления задачи
                SaveTasks(); // Сохраняем задачи после добавления
            }
        }

        private void TaskList_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (TaskList.SelectedItem is TaskItem selectedTask)
            {
                TaskDetails.Text = selectedTask.Description;
            }
            else
            {
                TaskDetails.Text = string.Empty;
            }
        }

        private void DeleteTask_Click(object sender, RoutedEventArgs e)
        {
            if (TaskList.SelectedItem is TaskItem selectedTask)
            {
                // Удаляем только из основной коллекции задач
                Tasks.Remove(selectedTask);
                UpdateTaskList(); // Обновляем список после удаления задачи
                SaveTasks(); // Сохраняем задачи после удаления
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите задачу для её удаления.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void MarkTaskAsComplete(object sender, RoutedEventArgs e)
        {
            if (TaskList.SelectedItem is TaskItem selectedTask)
            {
                selectedTask.IsComplete = true; // отмечаем задачу как завершенную
                UpdateTaskList(); // Обновляем содержимое списка
                SaveTasks(); // Сохраняем задачи после изменения
            }
        }

        private void ShowCompletedTasks_Click(object sender, RoutedEventArgs e)
        {
            showCompletedTasks = true; // Устанавливаем флаг для показа завершенных задач
            UpdateTaskList();
        }

        private void TasksClass_Click(object sender, RoutedEventArgs e)
        {
            showCompletedTasks = false; // Устанавливаем флаг для показа невыполненных задач
            UpdateTaskList();
        }

        private void HistoryTasks_Click(object sender, RoutedEventArgs e)
        {
            showCompletedTasks = true; // Устанавливаем флаг для показа завершенных задач
            UpdateTaskList();
        }

        private void UpdateTaskList()
        {
            var filteredTasks = showCompletedTasks
                ? Tasks.Where(t => t.IsComplete)
                : Tasks.Where(t => !t.IsComplete);

            TaskList.ItemsSource = new ObservableCollection<TaskItem>(filteredTasks);
        }


        // Сохранение задач в файл
        private void SaveTasks()
        {
            var json = JsonConvert.SerializeObject(Tasks, Formatting.Indented); // Изменено на Formatting.Indented
            File.WriteAllText(tasksFilePath, json);
        }


        // Загрузка задач из файла
        private void LoadTasks()
        {
            if (File.Exists(tasksFilePath))
            {
                var json = File.ReadAllText(tasksFilePath);
                var tasks = JsonConvert.DeserializeObject<List<TaskItem>>(json); // Изменено на List<TaskItem>
                if (tasks != null)
                {
                    Tasks.Clear(); // Очищаем текущие задачи
                    foreach (var task in tasks)
                    {
                        Tasks.Add(task);
                    }
                }
            }
        }

        public class TaskItem : System.ComponentModel.INotifyPropertyChanged
        {
            private bool isComplete;
            public bool IsComplete
            {
                get => isComplete;
                set
                {
                    isComplete = value;
                    OnPropertyChanged(nameof(IsComplete));
                }
            }

            public string Title { get; set; }
            public string Description { get; set; }

            public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

            protected void OnPropertyChanged(string propertyName)
            {
                PropertyChanged?.Invoke(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
