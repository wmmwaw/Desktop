﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Todo
{
    public class TaskModel
    {
        public int Id { get; set; }
        public bool IsCompleted { get; set; }
        public string Title { get; set; }
        public DateTime DueDate { get; set; }
        public string Description { get; set; }
        public string Category { get; set; }
        public string Time => DueDate.ToString("HH:mm");
        public DateTime Date { get; set; }

        public class Coordinate
        {
            public string Longitude { get; set; }
            public string Latitude { get; set; }
        }
    }
}

