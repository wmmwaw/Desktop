﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Todo;
using Todo.Entities;

public static class ApiClient
{
    private static readonly HttpClient _httpClient = new HttpClient();
    private static string _token = string.Empty;
    private const string BaseUrl = "http://45.144.64.179/api/";

    static ApiClient()
    {
        _httpClient.BaseAddress = new Uri(BaseUrl);
        _httpClient.DefaultRequestHeaders.Accept.Clear();
        _httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
    }

    public static void SetToken(string token)
    {
        if (!string.IsNullOrEmpty(token))
        {
            _token = token;
            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJodHRwOi8vc2NoZW1hcy54bWxzb2FwLm9yZy93cy8yMDA1LzA1L2lkZW50aXR5L2NsYWltcy9uYW1lIjoiYTg5MjZjMzItNzQyMi00ZDZjLTg1YjMtODg5ZDY3ZDdjZTljIiwibmJmIjoxNzQzMjgwNzM2LCJleHAiOjE3NDM0OTY3MzYsImlzcyI6Ik15QXV0aFNlcnZlciIsImF1ZCI6Ik15QXV0aENsaWVudCJ9.CymJn3LDgtAPn2ofRMuuaj20-eKhe9a110pOCSPGFc4", _token);
        }
    }



    public static async Task<bool> LoginAsync(string email, string password)
    {
        try
        {
            var loginModel = new { Email = email, Password = password };
            var json = JsonConvert.SerializeObject(loginModel);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            var response = await _httpClient.PostAsync("auth/login", content);

            if (response.IsSuccessStatusCode)
            {
                var responseContent = await response.Content.ReadAsStringAsync();
                var tokenResponse = JsonConvert.DeserializeObject<TokenResponse>(responseContent);
                SetToken(tokenResponse.Token);
                return true;
            }
            return false;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Login error: {ex.Message}");
            return false;
        }
    }

    public static async Task<bool> RegisterAsync(string email, string password)
    {
        try
        {
            var registerModel = new { Email = email, Password = password };
            var json = JsonConvert.SerializeObject(registerModel);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            var response = await _httpClient.PostAsync("auth/register", content);

            return response.IsSuccessStatusCode;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Register error: {ex.Message}");
            return false;
        }
    }


    public static async Task<List<TaskModel>> GetTasksAsync()
    {
        try
        {
            var response = await _httpClient.GetAsync("todos");
            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<List<TaskModel>>(content);
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Get tasks error: {ex.Message}");
        }
        return new List<TaskModel>();
    }

    public static async Task<TaskModel> GetTaskByIdAsync(int id)
    {
        try
        {
            var response = await _httpClient.GetAsync($"todos/{id}");
            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<TaskModel>(content);
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Get task by ID error: {ex.Message}");
        }
        return null;
    }

    public static async Task<TaskModel> CreateTaskAsync(TaskModel task)
    {
        try
        {
            var json = JsonConvert.SerializeObject(task);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            var response = await _httpClient.PostAsync("todos", content);
            if (response.IsSuccessStatusCode)
            {
                var responseContent = await response.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<TaskModel>(responseContent);
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Create task error: {ex.Message}");
        }
        return null;
    }

    public static async Task<bool> UpdateTaskAsync(TaskModel task)
    {
        try
        {
            var json = JsonConvert.SerializeObject(task);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            var response = await _httpClient.PutAsync($"todos/{task.Id}", content);
            return response.IsSuccessStatusCode;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Update task error: {ex.Message}");
            return false;
        }
    }

    public static async Task<bool> DeleteTaskAsync(int id)
    {
        try
        {
            var response = await _httpClient.DeleteAsync($"todos/{id}");
            return response.IsSuccessStatusCode;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Delete task error: {ex.Message}");
            return false;
        }
    }

    private class TokenResponse
    {
        public string Token { get; set; }
    }
}